import Dropdown from "./Dropdown";
function App() {

  return (
    <>
    
      <div className="App">
        <h1>Chose your programming Language!</h1>
        
      </div>
      <Dropdown/>
      </>

  
  );
}

export default App;
